package com.loc.newsapp.util

object Constants {

    const val USER_SETTINGS = "user_settings"
    const val APP_ENTRY = "app_entry"

    const val BASE_URL = "https://newsapi.org/v2/"
    const val API_KEY = "fee38bf418b04948b7b372c045fdf499"

}